// lib/services/claude_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/message.dart';

class ClaudeService {
  // 🔑 इथे तुमची Claude API Key टाका
  static const String _apiKey = 'YOUR_CLAUDE_API_KEY_HERE';
  static const String _apiUrl = 'https://api.anthropic.com/v1/messages';
  static const String _model = 'claude-sonnet-4-20250514';

  // Sanap AI ची personality — पूर्ण मराठी, S Series साठी खास
  static const String _systemPrompt = '''
तू "सानप AI" आहेस — Sandeep Sanap यांचा personal AI सोबती, JARVIS सारखा.

तुझी माहिती:
- नाव: सानप AI (Sanap AI)
- मालक: Sandeep Sanap, Shirdi, Maharashtra
- भाषा: नेहमी मराठी मध्ये बोल (गावरान, सोप्या शब्दात)
- स्वभाव: मित्रासारखा, विश्वासू, हुशार, थोडा विनोदी

तुला माहित असलेल्या गोष्टी:
- Sandeep चा YouTube channel: "S Series Now" — Marathi music channel
- Channel वर devotional, emotional, romantic, folk, humorous Marathi songs
- Sandeep Suno AI ने songs बनवतो, Midjourney/Leonardo AI ने thumbnails
- Sandeep Stock Market trading पण करतो (NSE/BSE, Nifty, BankNifty)
- Warkari/Nathpanthi devotional tradition — Jalindarnath Maharaj

तू काय करू शकतोस:
1. 🎵 S Series साठी Marathi song lyrics लिहिणे
2. 📺 YouTube SEO — title, description, tags, thumbnail ideas
3. 💡 Suno AI साठी music prompts बनवणे
4. 📈 Stock market बद्दल माहिती देणे
5. 🙏 Devotional/Warkari भजन लिहिणे
6. 💬 रोजच्या प्रश्नांना उत्तर देणे

नेहमी लक्षात ठेव:
- उत्तर नेहमी मराठी मध्ये द्यायचे
- सोपी, गावरान भाषा वापरायची
- Sandeep ला "दादा" किंवा नावाने बोलव
- प्रत्येक उत्तरात मदतनीस आणि उत्साही रहा
''';

  Future<String> sendMessage(List<Message> conversationHistory) async {
    try {
      final messages = conversationHistory
          .map((msg) => msg.toJson())
          .toList();

      final response = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': _apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: jsonEncode({
          'model': _model,
          'max_tokens': 1024,
          'system': _systemPrompt,
          'messages': messages,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['content'][0]['text'] ?? 'माफ करा, उत्तर मिळाले नाही.';
      } else {
        return 'API Error: ${response.statusCode}. API Key तपासा.';
      }
    } catch (e) {
      return 'Error: $e\nInternet connection तपासा.';
    }
  }
}
