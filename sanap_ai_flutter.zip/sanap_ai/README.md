# 🤖 सानप AI — Flutter App

## तुमचा वैयक्तिक JARVIS — मराठीत!

---

## 📁 File Structure
```
sanap_ai/
├── lib/
│   ├── main.dart              ← App entry + Splash Screen
│   ├── screens/
│   │   └── chat_screen.dart   ← Main Chat UI
│   ├── services/
│   │   └── claude_service.dart ← Claude API
│   └── models/
│       └── message.dart       ← Message Model
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml ← Permissions
└── pubspec.yaml               ← Dependencies
```

---

## ⚙️ Setup Steps (सेटअप कसे करायचे)

### Step 1: Flutter Install करा
```
https://flutter.dev/docs/get-started/install
```

### Step 2: Project तयार करा
```bash
flutter create sanap_ai
cd sanap_ai
```

### Step 3: हे सर्व files copy करा
वरील सर्व files त्यांच्या folders मध्ये paste करा.

### Step 4: Claude API Key मिळवा
1. https://console.anthropic.com वर जा
2. Account बनवा (Free $5 credits मिळतात)
3. API Key copy करा

### Step 5: API Key टाका
`lib/services/claude_service.dart` उघडा:
```dart
static const String _apiKey = 'YOUR_CLAUDE_API_KEY_HERE';
// ↑ इथे तुमची API Key टाका
```

### Step 6: App Run करा
```bash
flutter pub get
flutter run
```

---

## 🎯 Features
- ✅ मराठी Chat Interface
- ✅ Voice Input (मायक्रोफोन)
- ✅ AI Voice Output (TTS)
- ✅ S Series YouTube मदत
- ✅ JARVIS style Dark UI
- ✅ Quick Suggestion Chips
- ✅ Animated Splash Screen

---

## 🔧 API Key नंतर बदलायची असेल तर
`claude_service.dart` मध्ये `_apiKey` variable बदला.

---

**बनवले:** Claude AI + Sandeep Sanap
**Channel:** S Series Now, Shirdi 🙏
